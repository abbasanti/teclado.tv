#!/bin/bash
# Compila el APK en Ubuntu/Debian. Paquetes necesarios:
#   apt install default-jdk android-sdk-platform-23 aapt apksigner zipalign dalvik-exchange zip
set -euo pipefail
cd "$(dirname "$0")"
JAR=${ANDROID_JAR:-/usr/lib/android-sdk/platforms/android-23/android.jar}
rm -rf build && mkdir -p build/clases build/gen
aapt2 compile --dir res -o build/res.zip
aapt2 link -I "$JAR" --manifest AndroidManifest.xml -o build/base.apk build/res.zip --java build/gen
javac -nowarn -encoding utf-8 -source 8 -target 8 -bootclasspath "$JAR" -d build/clases src/ar/santi/tecladotv/*.java
dalvik-exchange --dex --min-sdk-version=21 --output=build/classes.dex build/clases
(cd build && zip -q -j base.apk classes.dex)
zipalign -f 4 build/base.apk build/alineado.apk
apksigner sign --ks firma.keystore --ks-pass pass:tecladotv --out TecladoTV.apk build/alineado.apk
apksigner verify --min-sdk-version 21 TecladoTV.apk
echo "Listo: TecladoTV.apk"
