package ar.santi.tecladotv;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    public static final String[] TEMAS = {"Oscuro", "Claro", "Negro"};
    public static final String[] COLORES = {"Celeste", "Verde", "Naranja", "Violeta"};
    public static final String[] TAMANOS = {"Chico", "Mediano", "Grande"};
    public static final String[] ORDENES = {"QWERTY", "ABC"};
    public static final String[] SINO = {"Sí", "No"};

    public static SharedPreferences de(Context c) {
        return c.getSharedPreferences("prefs", Context.MODE_PRIVATE);
    }

    public static int get(Context c, String clave) {
        return de(c).getInt(clave, clave.equals("tamano") ? 1 : 0);
    }
}
