package ar.santi.tecladotv;

import android.content.Context;
import android.content.Intent;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

import java.util.HashSet;
import java.util.Set;

public class TecladoService extends InputMethodService implements TecladoView.Toques {
    private static final int ESPERA_LARGA = 500, ESPERA_REPETIR = 400, RITMO = 70;

    private TecladoView vista;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Set<Integer> consumidas = new HashSet<Integer>();
    private Modelo.Tecla presionada;
    private int teclaSostenida;          // código de la tecla que mantiene la pulsación
    private boolean elegirVariante;
    private boolean shiftAutomatico;
    private int repeticiones;
    private String contextual = "@";

    private final Runnable pulsacionLarga = new Runnable() {
        public void run() {
            if (presionada == null || vista == null) return;
            String v = Modelo.variantes(presionada.texto);
            if (v.length() == 0) return;
            // Al final va la propia tecla, por si se mantuvo apretada sin querer.
            vista.variantes = v + presionada.texto;
            vista.variante = 0;
            presionada = null;
            vista.invalidate();
        }
    };

    private final Runnable repetirBorrado = new Runnable() {
        public void run() {
            repeticiones++;
            // Tope de seguridad por si el control no avisa que se soltó el botón.
            if (repeticiones > 300) return;
            if (repeticiones > 25) {
                borrarPalabra();
                h.postDelayed(this, RITMO * 3);
            } else {
                borrar();
                h.postDelayed(this, RITMO);
            }
            actualizar();
        }
    };

    private final Runnable refrescar = new Runnable() {
        public void run() { leerPrevia(); }
    };

    @Override
    public View onCreateInputView() {
        vista = new TecladoView(this, this);
        aplicarPrefs();
        vista.modelo.armar(Modelo.PAG_LETRAS, Prefs.get(this, "orden") == 1, contextual);
        vista.modelo.enfocar(1, 0);
        return vista;
    }

    private void aplicarPrefs() {
        vista.configurar(Prefs.get(this, "tema"), Prefs.get(this, "color"),
                Prefs.get(this, "tamano"), Prefs.get(this, "previa") == 0);
    }

    /** La pantalla completa taparía la app; en TV se usa siempre el modo compacto. */
    @Override
    public boolean onEvaluateFullscreenMode() { return false; }

    /** Algunos equipos declaran el control como teclado físico: mostrar igual. */
    @Override
    public boolean onEvaluateInputViewShown() {
        super.onEvaluateInputViewShown();
        return true;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean reinicio) {
        super.onStartInputView(info, reinicio);
        if (vista == null) return;
        cancelar();
        consumidas.clear();
        aplicarPrefs();

        int clase = info.inputType & InputType.TYPE_MASK_CLASS;
        int variacion = info.inputType & InputType.TYPE_MASK_VARIATION;
        contextual = clase == InputType.TYPE_CLASS_TEXT
                && variacion == InputType.TYPE_TEXT_VARIATION_URI ? "/" : "@";
        int pagina = clase == InputType.TYPE_CLASS_NUMBER || clase == InputType.TYPE_CLASS_PHONE
                || clase == InputType.TYPE_CLASS_DATETIME ? Modelo.PAG_NUMEROS : Modelo.PAG_LETRAS;
        if (!reinicio) {
            cambiarPagina(pagina);
            vista.modelo.enfocar(pagina == Modelo.PAG_NUMEROS ? 0 : 1, 0);
            vista.shift = 0;
            vista.acento = false;
        }
        vista.accion = nombreAccion(info);
        vista.pista = info.hintText == null ? "" : info.hintText.toString();
        mayusculaAutomatica();
        actualizar();
    }

    @Override
    public void onFinishInputView(boolean fin) {
        cancelar();
        super.onFinishInputView(fin);
    }

    @Override
    public void onUpdateSelection(int a, int b, int c, int d, int e, int f) {
        super.onUpdateSelection(a, b, c, d, e, f);
        actualizar();
    }

    // ---------- Control remoto ----------

    private static boolean tecladoFisico(KeyEvent e) {
        return e.getDevice() != null
                && e.getDevice().getKeyboardType() == InputDevice.KEYBOARD_TYPE_ALPHABETIC;
    }

    @Override
    public boolean onKeyDown(int codigo, KeyEvent e) {
        if (vista == null || !isInputViewShown()) return super.onKeyDown(codigo, e);
        boolean primera = e.getRepeatCount() == 0;
        boolean seleccionar = codigo == KeyEvent.KEYCODE_DPAD_CENTER
                || codigo == KeyEvent.KEYCODE_BUTTON_A
                || ((codigo == KeyEvent.KEYCODE_ENTER || codigo == KeyEvent.KEYCODE_NUMPAD_ENTER)
                && !tecladoFisico(e));

        if (vista.variantes != null) {
            int n = vista.variantes.length();
            if (codigo == KeyEvent.KEYCODE_DPAD_LEFT) vista.variante = (vista.variante + n - 1) % n;
            else if (codigo == KeyEvent.KEYCODE_DPAD_RIGHT) vista.variante = (vista.variante + 1) % n;
            else if (seleccionar) {
                if (primera) elegirVariante = true;
            } else if (codigo == KeyEvent.KEYCODE_BACK) vista.variantes = null;
            else if (codigo != KeyEvent.KEYCODE_DPAD_UP && codigo != KeyEvent.KEYCODE_DPAD_DOWN)
                return super.onKeyDown(codigo, e);
            consumidas.add(codigo);
            vista.invalidate();
            return true;
        }

        int dir = -1;
        if (codigo == KeyEvent.KEYCODE_DPAD_UP) dir = Modelo.ARRIBA;
        if (codigo == KeyEvent.KEYCODE_DPAD_DOWN) dir = Modelo.ABAJO;
        if (codigo == KeyEvent.KEYCODE_DPAD_LEFT) dir = Modelo.IZQUIERDA;
        if (codigo == KeyEvent.KEYCODE_DPAD_RIGHT) dir = Modelo.DERECHA;
        if (dir >= 0) {
            cancelar();
            vista.modelo.mover(dir);
            vista.invalidate();
            consumidas.add(codigo);
            return true;
        }
        if (seleccionar) {
            if (primera) {
                presionar(vista.modelo.actual());
                teclaSostenida = codigo;
            }
            consumidas.add(codigo);
            return true;
        }

        // Atajos para controles con más botones y joysticks.
        int atajo = -1;
        switch (codigo) {
            case KeyEvent.KEYCODE_MEDIA_REWIND:
            case KeyEvent.KEYCODE_PROG_RED:
            case KeyEvent.KEYCODE_BUTTON_X:
                atajo = Modelo.BORRAR;
                break;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
            case KeyEvent.KEYCODE_PROG_GREEN:
            case KeyEvent.KEYCODE_BUTTON_Y:
                atajo = Modelo.ESPACIO;
                break;
            case KeyEvent.KEYCODE_PROG_YELLOW:
            case KeyEvent.KEYCODE_BUTTON_SELECT:
                atajo = vista.modelo.pagina == Modelo.PAG_LETRAS ? Modelo.SIMBOLOS : Modelo.LETRAS;
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_PROG_BLUE:
            case KeyEvent.KEYCODE_BUTTON_START:
                atajo = Modelo.ENTER;
                break;
        }
        if (atajo >= 0) {
            consumidas.add(codigo);
            if (primera) {
                cancelar();
                if (atajo == Modelo.BORRAR) {
                    presionar(new Modelo.Tecla(atajo, "", 1));
                    teclaSostenida = codigo;
                } else {
                    ejecutar(new Modelo.Tecla(atajo, "", 1));
                }
            }
            return true;
        }
        return super.onKeyDown(codigo, e);
    }

    @Override
    public boolean onKeyUp(int codigo, KeyEvent e) {
        if (!consumidas.remove(codigo)) return super.onKeyUp(codigo, e);
        if (vista != null && vista.variantes != null) {
            if (elegirVariante) confirmarVariante(vista.variante);
        } else if (codigo == teclaSostenida) {
            soltar();
        }
        return true;
    }

    // ---------- Puntero ----------

    public void tocarAbajo(int fila, int col) {
        cancelar();
        vista.modelo.enfocar(fila, col);
        presionar(vista.modelo.actual());
        vista.invalidate();
    }

    public void tocarArriba() { soltar(); }

    public void tocarVariante(int i) {
        if (i >= 0) confirmarVariante(i);
        else {
            vista.variantes = null;
            vista.invalidate();
        }
    }

    // ---------- Acciones ----------

    private void presionar(Modelo.Tecla t) {
        cancelar();
        presionada = t;
        if (t.tipo == Modelo.BORRAR) {
            borrar();
            actualizar();
            h.postDelayed(repetirBorrado, ESPERA_REPETIR);
        } else if (t.tipo == Modelo.TEXTO) {
            h.postDelayed(pulsacionLarga, ESPERA_LARGA);
        }
    }

    private void soltar() {
        // Con la ventana de variantes abierta, soltar no la cierra.
        if (vista == null || vista.variantes != null) return;
        Modelo.Tecla t = presionada;
        cancelar();
        if (t != null && t.tipo != Modelo.BORRAR) ejecutar(t);
        else if (t != null) {
            mayusculaAutomatica();
            actualizar();
        }
    }

    private void cancelar() {
        h.removeCallbacks(pulsacionLarga);
        h.removeCallbacks(repetirBorrado);
        presionada = null;
        teclaSostenida = 0;
        repeticiones = 0;
        elegirVariante = false;
        if (vista != null) vista.variantes = null;
    }

    private void confirmarVariante(int i) {
        String s = vista.variantes.substring(i, i + 1);
        vista.variantes = null;
        elegirVariante = false;
        vista.acento = false;
        escribir(s);
        actualizar();
    }

    private void ejecutar(Modelo.Tecla t) {
        InputConnection ic = getCurrentInputConnection();
        switch (t.tipo) {
            case Modelo.TEXTO:
                escribir(t.texto);
                break;
            case Modelo.ESPACIO:
                vista.acento = false;
                if (ic != null) ic.commitText(" ", 1);
                mayusculaAutomatica();
                break;
            case Modelo.SHIFT:
                vista.shift = (vista.shift + 1) % 3;
                shiftAutomatico = false;
                break;
            case Modelo.ACENTO:
                vista.acento = !vista.acento;
                break;
            case Modelo.LIMPIAR:
                if (ic != null) {
                    ic.beginBatchEdit();
                    ic.finishComposingText();
                    ic.commitText("", 1);
                    ic.deleteSurroundingText(100000, 100000);
                    ic.endBatchEdit();
                }
                mayusculaAutomatica();
                break;
            case Modelo.ENTER:
                enter();
                break;
            case Modelo.SIMBOLOS:
                cambiarPagina(Modelo.PAG_SIMBOLOS);
                vista.modelo.enfocarTipo(Modelo.LETRAS);
                break;
            case Modelo.LETRAS:
                cambiarPagina(Modelo.PAG_LETRAS);
                vista.modelo.enfocarTipo(Modelo.SIMBOLOS);
                break;
            case Modelo.CAMBIAR:
                InputMethodManager imm =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showInputMethodPicker();
                break;
            case Modelo.AJUSTES:
                requestHideSelf(0);
                startActivity(new Intent(this, ConfigActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                break;
            case Modelo.IZQ:
                moverCursor(-1);
                break;
            case Modelo.DER:
                moverCursor(1);
                break;
            case Modelo.OCULTAR:
                requestHideSelf(0);
                break;
        }
        actualizar();
    }

    private void escribir(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (vista.shift > 0 && s.length() == 1 && !s.equals("ß")) s = s.toUpperCase();
        if (vista.acento) s = Modelo.acentuar(s);
        vista.acento = false;
        if (ic != null) ic.commitText(s, 1);
        if (vista.shift == 1) vista.shift = 0;
        mayusculaAutomatica();
    }

    /** Activa o quita la mayúscula según lo que pida el campo, sin pisar la elegida a mano. */
    private void mayusculaAutomatica() {
        if (vista == null || vista.shift == 2 || (vista.shift == 1 && !shiftAutomatico)) return;
        InputConnection ic = getCurrentInputConnection();
        EditorInfo info = getCurrentInputEditorInfo();
        boolean mayus = ic != null && info != null
                && (info.inputType & InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT
                && ic.getCursorCapsMode(info.inputType) != 0;
        vista.shift = mayus ? 1 : 0;
        shiftAutomatico = mayus;
    }

    private void borrar() {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo info = getCurrentInputEditorInfo();
        if (ic == null) return;
        if (info == null || info.inputType == InputType.TYPE_NULL) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
            return;
        }
        CharSequence seleccion = ic.getSelectedText(0);
        if (seleccion != null && seleccion.length() > 0) {
            ic.commitText("", 1);
            return;
        }
        CharSequence antes = ic.getTextBeforeCursor(2, 0);
        if (antes == null) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
            return;
        }
        int n = antes.length() == 2 && Character.isSurrogatePair(antes.charAt(0), antes.charAt(1)) ? 2 : 1;
        ic.deleteSurroundingText(n, 0);
    }

    private void borrarPalabra() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence antes = ic.getTextBeforeCursor(60, 0);
        if (antes == null || antes.length() == 0) {
            borrar();
            return;
        }
        int i = antes.length();
        while (i > 0 && Character.isWhitespace(antes.charAt(i - 1))) i--;
        while (i > 0 && !Character.isWhitespace(antes.charAt(i - 1))) i--;
        ic.deleteSurroundingText(antes.length() - i, 0);
    }

    private void moverCursor(int paso) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ExtractedText t = ic.getExtractedText(new ExtractedTextRequest(), 0);
        if (t == null || t.text == null || t.selectionStart < 0) {
            sendDownUpKeyEvents(paso < 0 ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT);
            return;
        }
        int pos = (paso < 0 ? Math.min(t.selectionStart, t.selectionEnd)
                : Math.max(t.selectionStart, t.selectionEnd)) + paso;
        pos = Math.max(0, Math.min(pos, t.text.length()));
        ic.setSelection(t.startOffset + pos, t.startOffset + pos);
    }

    private static int accionDe(EditorInfo info) {
        if (info == null || (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0)
            return EditorInfo.IME_ACTION_NONE;
        if (info.actionLabel != null) return info.actionId;
        return info.imeOptions & EditorInfo.IME_MASK_ACTION;
    }

    private static String nombreAccion(EditorInfo info) {
        if (info == null || (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "";
        if (info.actionLabel != null) return info.actionLabel.toString();
        switch (info.imeOptions & EditorInfo.IME_MASK_ACTION) {
            case EditorInfo.IME_ACTION_GO: return "Ir";
            case EditorInfo.IME_ACTION_SEARCH: return "Buscar";
            case EditorInfo.IME_ACTION_SEND: return "Enviar";
            case EditorInfo.IME_ACTION_NEXT: return "Siguiente";
            case EditorInfo.IME_ACTION_DONE: return "Listo";
            case EditorInfo.IME_ACTION_PREVIOUS: return "Anterior";
            default: return "";
        }
    }

    private void enter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        EditorInfo info = getCurrentInputEditorInfo();
        int accion = accionDe(info);
        boolean propia = info != null && info.actionLabel != null
                && (info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0;
        if (propia || (accion != EditorInfo.IME_ACTION_NONE
                && accion != EditorInfo.IME_ACTION_UNSPECIFIED)) {
            ic.performEditorAction(accion);
        } else if (info != null
                && (info.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
                && (info.inputType & InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT) {
            ic.commitText("\n", 1);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        }
    }

    private void cambiarPagina(int pagina) {
        vista.modelo.armar(pagina, Prefs.get(this, "orden") == 1, contextual);
        vista.modelo.enfocar(vista.modelo.fila, vista.modelo.col);
        if (pagina != Modelo.PAG_LETRAS) {
            vista.shift = 0;
            vista.acento = false;
        }
        vista.requestLayout();
    }

    private void actualizar() {
        if (vista == null) return;
        vista.invalidate();
        h.removeCallbacks(refrescar);
        h.postDelayed(refrescar, 40);
    }

    private static boolean esClave(int tipo) {
        int clase = tipo & InputType.TYPE_MASK_CLASS;
        int v = tipo & InputType.TYPE_MASK_VARIATION;
        if (clase == InputType.TYPE_CLASS_TEXT)
            return v == InputType.TYPE_TEXT_VARIATION_PASSWORD
                    || v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD;
        return clase == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD;
    }

    /** Lee el texto cercano al cursor para la barra de vista previa. */
    private void leerPrevia() {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo info = getCurrentInputEditorInfo();
        if (vista == null || ic == null || info == null) return;
        CharSequence a = ic.getTextBeforeCursor(120, 0);
        CharSequence d = ic.getTextAfterCursor(60, 0);
        String antes = a == null ? "" : a.toString();
        String despues = d == null ? "" : d.toString();
        if (esClave(info.inputType)) {
            antes = puntos(antes.length());
            despues = puntos(despues.length());
        }
        vista.previa = antes.length() + despues.length() == 0 ? ""
                : (antes + "|" + despues).replace('\n', ' ');
        vista.invalidate();
    }

    private static String puntos(int n) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < n; i++) s.append('•');
        return s.toString();
    }
}
