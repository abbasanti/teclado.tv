package ar.santi.tecladotv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class ConfigActivity extends Activity {
    private TextView estado;
    private LinearLayout col;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF101317);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(48), dp(32), dp(48), dp(320));
        scroll.addView(col);

        texto("Teclado TV", 30, Color.WHITE);
        estado = texto("", 16, 0xFFB8C0CC);

        Button activar = boton("1. Activar el teclado");
        activar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { abrirAjustes(); }
        });
        Button elegir = boton("2. Elegirlo como teclado actual");
        elegir.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!activado()) aviso("Primero activalo en el paso 1");
                else imm().showInputMethodPicker();
            }
        });

        EditText prueba = new EditText(this);
        prueba.setHint("Probá el teclado acá");
        prueba.setTextColor(Color.WHITE);
        prueba.setHintTextColor(0xFF8C95A3);
        prueba.setSingleLine(true);
        prueba.setImeOptions(EditorInfo.IME_ACTION_DONE);
        prueba.setBackground(fondoFoco(0xFF1B2027, 0xFF2E4658));
        prueba.setPadding(dp(16), dp(12), dp(16), dp(12));
        agregar(prueba);

        texto("Apariencia", 20, Color.WHITE);
        opcion("Tema", "tema", Prefs.TEMAS);
        opcion("Color de resaltado", "color", Prefs.COLORES);
        opcion("Tamaño", "tamano", Prefs.TAMANOS);
        opcion("Orden de las letras", "orden", Prefs.ORDENES);
        opcion("Barra con vista previa del texto", "previa", Prefs.SINO);

        texto("Mantené OK sobre una letra para ver acentos y símbolos. Mantené OK sobre "
                + "borrar para borrar seguido. Los cambios se ven la próxima vez que se abre "
                + "el teclado.", 15, 0xFFB8C0CC);

        setContentView(scroll);
        activar.requestFocus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        actualizarEstado();
    }

    @Override
    public void onWindowFocusChanged(boolean foco) {
        super.onWindowFocusChanged(foco);
        if (foco) actualizarEstado();
    }

    private InputMethodManager imm() {
        return (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    private boolean activado() {
        for (InputMethodInfo i : imm().getEnabledInputMethodList())
            if (i.getPackageName().equals(getPackageName())) return true;
        return false;
    }

    private void actualizarEstado() {
        String actual = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.DEFAULT_INPUT_METHOD);
        boolean enUso = actual != null && actual.startsWith(getPackageName() + "/");
        estado.setText("Activado: " + (activado() ? "sí" : "no")
                + "     En uso: " + (enUso ? "sí" : "no"));
    }

    private void abrirAjustes() {
        try {
            startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
                aviso("Entrá en Sistema > Teclado y activá Teclado TV");
            } catch (Exception otra) {
                aviso("Abrí los ajustes del televisor y buscá Teclado");
            }
        }
    }

    private void aviso(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private void opcion(final String nombre, final String clave, final String[] valores) {
        final Button b = boton(nombre + ": " + valores[Prefs.get(this, clave)]);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int n = (Prefs.get(ConfigActivity.this, clave) + 1) % valores.length;
                Prefs.de(ConfigActivity.this).edit().putInt(clave, n).apply();
                b.setText(nombre + ": " + valores[n]);
            }
        });
    }

    private TextView texto(String s, int tam, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(tam);
        t.setTextColor(color);
        agregar(t);
        return t;
    }

    private Button boton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(17);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setBackground(fondoFoco(0xFF232932, 0xFF1479B8));
        b.setPadding(dp(16), dp(10), dp(16), dp(10));
        agregar(b);
        return b;
    }

    private StateListDrawable fondoFoco(int normal, int foco) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, caja(foco));
        s.addState(new int[]{android.R.attr.state_pressed}, caja(foco));
        s.addState(new int[]{}, caja(normal));
        return s;
    }

    private GradientDrawable caja(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(8));
        return g;
    }

    private void agregar(View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(6));
        col.addView(v, lp);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
