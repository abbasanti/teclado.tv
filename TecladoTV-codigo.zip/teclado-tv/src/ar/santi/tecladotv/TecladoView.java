package ar.santi.tecladotv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.List;

/** Dibuja el teclado. El estado lo maneja el servicio. */
public class TecladoView extends View {
    public interface Toques {
        void tocarAbajo(int fila, int col);
        void tocarArriba();
        void tocarVariante(int i);
    }

    public final Modelo modelo = new Modelo();
    public int shift;                 // 0 no, 1 una letra, 2 bloqueado
    public boolean acento;
    public String variantes;          // null = ventana cerrada
    public int variante;
    public String previa = "";
    public String pista = "";
    public String accion = "";        // texto de la tecla Enter

    private final Toques toques;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linea = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path path = new Path();
    private int fondo, tecla, especial, texto, tenue, color;
    private int tamano = 1;
    private boolean verPrevia = true;
    private float alto, anchoU, margenX, arriba, barra;
    private RectF[] cajas = new RectF[0];

    public TecladoView(Context c, Toques toques) {
        super(c);
        this.toques = toques;
        setFocusable(false);
    }

    public void configurar(int tema, int colorIdx, int tamano, boolean verPrevia) {
        int[][] temas = {
                {0xFF15181D, 0xFF2A2F38, 0xFF1F232A, 0xFFF4F6F8, 0xFF8C95A3},
                {0xFFDFE3E8, 0xFFFFFFFF, 0xFFC5CCD5, 0xFF16191E, 0xFF5D6672},
                {0xFF000000, 0xFF1C1C1C, 0xFF0F0F0F, 0xFFFFFFFF, 0xFF9A9A9A}};
        int[] colores = {0xFF5CC8FF, 0xFF5FD68B, 0xFFFFA94D, 0xFFB89CFF};
        int[] t = temas[tema];
        fondo = t[0];
        tecla = t[1];
        especial = t[2];
        texto = t[3];
        tenue = t[4];
        color = colores[colorIdx];
        this.tamano = tamano;
        this.verPrevia = verPrevia;
        requestLayout();
        invalidate();
    }

    @Override
    protected void onMeasure(int ws, int hs) {
        int ancho = MeasureSpec.getSize(ws);
        if (ancho == 0) ancho = getResources().getDisplayMetrics().widthPixels;
        float pantalla = getResources().getDisplayMetrics().heightPixels;
        float[] factor = {0.066f, 0.076f, 0.088f};
        alto = pantalla * factor[tamano];
        barra = verPrevia ? alto * 0.85f : 0;
        setMeasuredDimension(ancho, Math.round(alto * 5 + barra + alto * 0.35f));
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(fondo);
        float total = modelo.anchoTotal;
        if (total == 0) return;
        anchoU = Math.min(getWidth() * 0.92f / 12f, alto * 1.55f);
        margenX = (getWidth() - anchoU * total) / 2f;
        arriba = barra + alto * 0.15f;

        if (verPrevia) dibujarPrevia(c);

        for (int f = 0; f < modelo.filas.size(); f++) {
            List<Modelo.Tecla> fila = modelo.filas.get(f);
            for (int i = 0; i < fila.size(); i++) {
                Modelo.Tecla t = fila.get(i);
                boolean foco = f == modelo.fila && i == modelo.col;
                float sep = alto * (foco ? 0.025f : 0.065f);
                r.set(margenX + t.x * anchoU + sep, arriba + f * alto + sep,
                        margenX + (t.x + t.ancho) * anchoU - sep, arriba + (f + 1) * alto - sep);
                boolean activa = (t.tipo == Modelo.SHIFT && shift > 0)
                        || (t.tipo == Modelo.ACENTO && acento);
                boolean normal = t.tipo == Modelo.TEXTO || t.tipo == Modelo.ESPACIO;
                p.setStyle(Paint.Style.FILL);
                p.setColor(foco ? color : normal ? tecla : especial);
                c.drawRoundRect(r, alto * 0.16f, alto * 0.16f, p);
                if (activa && !foco) {
                    linea.setStyle(Paint.Style.STROKE);
                    linea.setStrokeWidth(alto * 0.05f);
                    linea.setColor(color);
                    c.drawRoundRect(r, alto * 0.16f, alto * 0.16f, linea);
                }
                contenido(c, t, foco ? 0xFF0B0D10 : texto);
            }
        }
        if (variantes != null) dibujarVariantes(c);
    }

    private void dibujarPrevia(Canvas c) {
        float w = anchoU * 12;
        float x = (getWidth() - w) / 2f;
        r.set(x + alto * 0.065f, alto * 0.14f, x + w - alto * 0.065f, barra);
        p.setStyle(Paint.Style.FILL);
        p.setColor(especial);
        c.drawRoundRect(r, alto * 0.16f, alto * 0.16f, p);
        p.setTextAlign(Paint.Align.LEFT);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(alto * 0.36f);
        boolean vacia = previa.length() == 0 || previa.equals("|");
        String s = vacia ? (pista.length() > 0 ? pista : "Escribí con el control remoto") : previa;
        float max = r.width() - alto * 0.6f;
        // Si no entra, se muestra la parte cercana al cursor.
        while (s.length() > 1 && p.measureText(s) > max) {
            int cursor = s.indexOf('|');
            s = cursor > s.length() / 2 ? s.substring(1) : s.substring(0, s.length() - 1);
        }
        p.setColor(vacia ? tenue : texto);
        c.drawText(s, r.left + alto * 0.3f, r.centerY() - (p.ascent() + p.descent()) / 2, p);
    }

    private void dibujarVariantes(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xB0000000);
        r.set(0, 0, getWidth(), getHeight());
        c.drawRect(r, p);
        int n = variantes.length();
        float lado = alto * 1.2f;
        float x = (getWidth() - n * lado) / 2f;
        float y = (getHeight() - lado) / 2f;
        p.setColor(fondo);
        r.set(x - alto * 0.2f, y - alto * 0.2f, x + n * lado + alto * 0.2f, y + lado + alto * 0.2f);
        c.drawRoundRect(r, alto * 0.25f, alto * 0.25f, p);
        cajas = new RectF[n];
        for (int i = 0; i < n; i++) {
            r.set(x + i * lado + alto * 0.06f, y + alto * 0.06f,
                    x + (i + 1) * lado - alto * 0.06f, y + lado - alto * 0.06f);
            cajas[i] = new RectF(r.left, r.top, r.right, r.bottom);
            p.setColor(i == variante ? color : tecla);
            c.drawRoundRect(r, alto * 0.16f, alto * 0.16f, p);
            String s = variantes.substring(i, i + 1);
            if (shift > 0 && !s.equals("ß")) s = s.toUpperCase();
            rotulo(c, s, i == variante ? 0xFF0B0D10 : texto, alto * 0.55f);
        }
    }

    private void rotulo(Canvas c, String s, int col, float tam) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(col);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(tam);
        while (p.measureText(s) > r.width() * 0.88f && p.getTextSize() > 8)
            p.setTextSize(p.getTextSize() * 0.92f);
        c.drawText(s, r.centerX(), r.centerY() - (p.ascent() + p.descent()) / 2, p);
    }

    private void contenido(Canvas c, Modelo.Tecla t, int col) {
        float cx = r.centerX(), cy = r.centerY(), u = alto * 0.19f;
        linea.setStyle(Paint.Style.STROKE);
        linea.setStrokeWidth(alto * 0.045f);
        linea.setStrokeCap(Paint.Cap.ROUND);
        linea.setStrokeJoin(Paint.Join.ROUND);
        linea.setColor(col);
        path.reset();
        switch (t.tipo) {
            case Modelo.TEXTO:
                String s = shift > 0 && t.texto.length() == 1 ? t.texto.toUpperCase() : t.texto;
                if (acento) s = Modelo.acentuar(s);
                rotulo(c, s, col, alto * 0.43f);
                return;
            case Modelo.ACENTO:
                rotulo(c, "á", col, alto * 0.43f);
                return;
            case Modelo.SIMBOLOS:
            case Modelo.LETRAS:
                rotulo(c, t.texto, col, alto * 0.34f);
                return;
            case Modelo.ESPACIO:
                rotulo(c, "espacio", col, alto * 0.3f);
                return;
            case Modelo.LIMPIAR:
                rotulo(c, "Limpiar", col, alto * 0.27f);
                return;
            case Modelo.ENTER:
                if (accion.length() > 0) {
                    rotulo(c, accion, col, alto * 0.34f);
                    return;
                }
                path.moveTo(cx + u, cy - u * 0.8f);
                path.lineTo(cx + u, cy + u * 0.2f);
                path.lineTo(cx - u, cy + u * 0.2f);
                path.moveTo(cx - u * 0.45f, cy - u * 0.35f);
                path.lineTo(cx - u, cy + u * 0.2f);
                path.lineTo(cx - u * 0.45f, cy + u * 0.75f);
                break;
            case Modelo.BORRAR:
                path.moveTo(cx - u * 1.35f, cy);
                path.lineTo(cx - u * 0.6f, cy - u * 0.8f);
                path.lineTo(cx + u * 1.2f, cy - u * 0.8f);
                path.lineTo(cx + u * 1.2f, cy + u * 0.8f);
                path.lineTo(cx - u * 0.6f, cy + u * 0.8f);
                path.close();
                path.moveTo(cx - u * 0.1f, cy - u * 0.38f);
                path.lineTo(cx + u * 0.65f, cy + u * 0.38f);
                path.moveTo(cx + u * 0.65f, cy - u * 0.38f);
                path.lineTo(cx - u * 0.1f, cy + u * 0.38f);
                break;
            case Modelo.SHIFT:
                path.moveTo(cx, cy - u);
                path.lineTo(cx + u, cy);
                path.lineTo(cx + u * 0.45f, cy);
                path.lineTo(cx + u * 0.45f, cy + u * 0.6f);
                path.lineTo(cx - u * 0.45f, cy + u * 0.6f);
                path.lineTo(cx - u * 0.45f, cy);
                path.lineTo(cx - u, cy);
                path.close();
                if (shift == 2) {
                    path.moveTo(cx - u * 0.45f, cy + u);
                    path.lineTo(cx + u * 0.45f, cy + u);
                }
                if (shift > 0) linea.setStyle(Paint.Style.FILL_AND_STROKE);
                break;
            case Modelo.CAMBIAR:   // globo
                c.drawCircle(cx, cy, u, linea);
                r.set(cx - u * 0.45f, cy - u, cx + u * 0.45f, cy + u);
                c.drawOval(r, linea);
                path.moveTo(cx - u, cy);
                path.lineTo(cx + u, cy);
                break;
            case Modelo.AJUSTES:   // controles deslizantes
                for (int i = -1; i <= 1; i++) {
                    path.moveTo(cx - u, cy + i * u * 0.7f);
                    path.lineTo(cx + u, cy + i * u * 0.7f);
                }
                p.setStyle(Paint.Style.FILL);
                p.setColor(col);
                c.drawCircle(cx + u * 0.4f, cy - u * 0.7f, u * 0.24f, p);
                c.drawCircle(cx - u * 0.45f, cy, u * 0.24f, p);
                c.drawCircle(cx + u * 0.1f, cy + u * 0.7f, u * 0.24f, p);
                break;
            case Modelo.IZQ:
            case Modelo.DER:
                float d = t.tipo == Modelo.IZQ ? -1 : 1;
                path.moveTo(cx - d * u * 0.35f, cy - u * 0.7f);
                path.lineTo(cx + d * u * 0.35f, cy);
                path.lineTo(cx - d * u * 0.35f, cy + u * 0.7f);
                break;
            case Modelo.OCULTAR:
                path.moveTo(cx - u * 0.8f, cy - u * 0.35f);
                path.lineTo(cx, cy + u * 0.45f);
                path.lineTo(cx + u * 0.8f, cy - u * 0.35f);
                break;
            default:
                return;
        }
        c.drawPath(path, linea);
    }

    /** Soporte para mouse, puntero o pantalla táctil. */
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            if (variantes != null) {
                int elegida = -1;
                for (int i = 0; i < cajas.length; i++)
                    if (cajas[i].contains(x, y)) elegida = i;
                toques.tocarVariante(elegida);
                return true;
            }
            int f = (int) Math.floor((y - arriba) / alto);
            if (f < 0 || f >= modelo.filas.size()) return true;
            float ux = (x - margenX) / anchoU;
            List<Modelo.Tecla> fila = modelo.filas.get(f);
            for (int i = 0; i < fila.size(); i++)
                if (ux >= fila.get(i).x && ux < fila.get(i).x + fila.get(i).ancho)
                    toques.tocarAbajo(f, i);
        } else if (e.getAction() == MotionEvent.ACTION_UP
                || e.getAction() == MotionEvent.ACTION_CANCEL) {
            toques.tocarArriba();
        }
        return true;
    }
}
