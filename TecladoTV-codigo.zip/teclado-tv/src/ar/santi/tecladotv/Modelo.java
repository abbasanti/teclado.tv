package ar.santi.tecladotv;

import java.util.ArrayList;
import java.util.List;

/** Distribuciones de teclas y navegación con control remoto (Java puro). */
public class Modelo {
    public static final int TEXTO = 0, SHIFT = 1, BORRAR = 2, LIMPIAR = 3, ENTER = 4, ESPACIO = 5,
            SIMBOLOS = 6, LETRAS = 7, CAMBIAR = 8, AJUSTES = 9, IZQ = 10, DER = 11,
            OCULTAR = 12, ACENTO = 13;
    public static final int PAG_LETRAS = 0, PAG_SIMBOLOS = 1, PAG_NUMEROS = 2;
    public static final int ARRIBA = 0, ABAJO = 1, IZQUIERDA = 2, DERECHA = 3;

    public static final class Tecla {
        public final int tipo;
        public final String texto;
        public final float ancho;
        public float x;
        Tecla(int tipo, String texto, float ancho) {
            this.tipo = tipo;
            this.texto = texto;
            this.ancho = ancho;
        }
        float centro() { return x + ancho / 2f; }
    }

    public final List<List<Tecla>> filas = new ArrayList<List<Tecla>>();
    public float anchoTotal;
    public int pagina;
    public int fila, col;
    /** Columna recordada para que subir y bajar no "derive" hacia un costado. */
    private float xPreferida;

    public void armar(int pagina, boolean abc, String simboloContextual) {
        this.pagina = pagina;
        filas.clear();
        if (pagina == PAG_NUMEROS) {
            fila(t("1"), t("2"), t("3"), k(BORRAR, 1));
            fila(t("4"), t("5"), t("6"), t("-"));
            fila(t("7"), t("8"), t("9"), t("."));
            fila(t(","), t("0"), t("+"), k(ENTER, 1));
            fila(new Tecla(LETRAS, "ABC", 1), k(IZQ, 1), k(DER, 1), k(OCULTAR, 1));
        } else {
            List<Tecla> numeros = letras("1234567890");
            numeros.add(k(BORRAR, 2));
            filas.add(numeros);
            if (pagina == PAG_SIMBOLOS) {
                filas.add(letras("@#$%&*-+()=/"));
                List<Tecla> f = letras("!\"':;¿?¡_\\");
                f.add(k(ENTER, 2));
                filas.add(f);
                filas.add(letras("[]{}<>|~^€°•"));
            } else {
                List<Tecla> a = letras(abc ? "abcdefghij" : "qwertyuiop");
                a.add(new Tecla(ACENTO, "´", 1));
                a.add(k(LIMPIAR, 1));
                filas.add(a);
                List<Tecla> b = letras(abc ? "klmnñopqrs" : "asdfghjklñ");
                b.add(k(ENTER, 2));
                filas.add(b);
                List<Tecla> c = new ArrayList<Tecla>();
                c.add(k(SHIFT, 1));
                c.addAll(letras(abc ? "tuvwxyz,.-?" : "zxcvbnm,.-?"));
                filas.add(c);
            }
            fila(pagina == PAG_SIMBOLOS ? new Tecla(LETRAS, "ABC", 2) : new Tecla(SIMBOLOS, "?123", 2),
                    k(CAMBIAR, 1), k(AJUSTES, 1), t(simboloContextual), k(ESPACIO, 3),
                    t(".com"), k(IZQ, 1), k(DER, 1), k(OCULTAR, 1));
        }
        anchoTotal = 0;
        for (List<Tecla> f : filas) {
            float x = 0;
            for (Tecla tecla : f) {
                tecla.x = x;
                x += tecla.ancho;
            }
            anchoTotal = Math.max(anchoTotal, x);
        }
    }

    private static Tecla t(String s) { return new Tecla(TEXTO, s, 1); }
    private static Tecla k(int tipo, float ancho) { return new Tecla(tipo, "", ancho); }
    private void fila(Tecla... teclas) {
        List<Tecla> f = new ArrayList<Tecla>();
        for (Tecla t : teclas) f.add(t);
        filas.add(f);
    }
    private static List<Tecla> letras(String s) {
        List<Tecla> f = new ArrayList<Tecla>();
        for (int i = 0; i < s.length(); i++) f.add(t(s.substring(i, i + 1)));
        return f;
    }

    public Tecla actual() { return filas.get(fila).get(col); }

    public void enfocar(int f, int c) {
        fila = Math.max(0, Math.min(f, filas.size() - 1));
        col = Math.max(0, Math.min(c, filas.get(fila).size() - 1));
        xPreferida = actual().centro();
    }

    /** Enfoca la primera tecla del tipo pedido; devuelve false si no existe. */
    public boolean enfocarTipo(int tipo) {
        for (int f = 0; f < filas.size(); f++)
            for (int c = 0; c < filas.get(f).size(); c++)
                if (filas.get(f).get(c).tipo == tipo) {
                    enfocar(f, c);
                    return true;
                }
        return false;
    }

    public void mover(int dir) {
        if (dir == IZQUIERDA || dir == DERECHA) {
            int n = filas.get(fila).size();
            col = (col + (dir == DERECHA ? 1 : n - 1)) % n;
            xPreferida = actual().centro();
        } else {
            int n = filas.size();
            fila = (fila + (dir == ABAJO ? 1 : n - 1)) % n;
            List<Tecla> f = filas.get(fila);
            float mejor = Float.MAX_VALUE;
            for (int i = 0; i < f.size(); i++) {
                Tecla t = f.get(i);
                // Distancia al borde más cercano de la tecla (0 si la columna cae adentro).
                float d = Math.max(0, Math.max(t.x - xPreferida, xPreferida - (t.x + t.ancho)));
                d = d * 100 + Math.abs(t.centro() - xPreferida);
                if (d < mejor) {
                    mejor = d;
                    col = i;
                }
            }
        }
    }

    public static String variantes(String s) {
        if (s.equals("a")) return "áàäâãª";
        if (s.equals("e")) return "éèëê€";
        if (s.equals("i")) return "íìïî";
        if (s.equals("o")) return "óòöôõº";
        if (s.equals("u")) return "úüùû";
        if (s.equals("n")) return "ñ";
        if (s.equals("c")) return "ç";
        if (s.equals("s")) return "ß$";
        if (s.equals(".")) return ",;:…•";
        if (s.equals(",")) return ";'\"";
        if (s.equals("?")) return "¿!¡";
        if (s.equals("-")) return "_–+=";
        if (s.equals("0")) return "°";
        if (s.equals("$")) return "€£¥¢";
        return "";
    }

    public static String acentuar(String s) {
        int i = "aeiouAEIOU".indexOf(s);
        return s.length() == 1 && i >= 0 ? "áéíóúÁÉÍÓÚ".substring(i, i + 1) : s;
    }
}
